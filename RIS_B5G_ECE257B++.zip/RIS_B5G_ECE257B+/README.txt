you can see the README for each folder
the result for folder "sum_rate_with_power" need more time to iterate
THANKS!!